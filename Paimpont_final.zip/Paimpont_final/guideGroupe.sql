USE paimpont;

-- Création de la vue du tableau guide-groupe
CREATE OR REPLACE VIEW VueguideGroupe AS
SELECT vf.dateForet, gu.prenom, gu.nom, gr.nomDuGroupe FROM guide gu LEFT JOIN groupe gr ON gu.idGuide = gr.idGuide
LEFT JOIN  visiteurForet vf ON gr.idGroupe = vf.idGroupe;


SELECT * FROM VueguideGroupe;


