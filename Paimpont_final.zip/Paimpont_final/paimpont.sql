USE paimpont;

-- Supprimer les tables dans l'ordre des dépendances
DROP TABLE IF EXISTS visiteurForet;
DROP TABLE IF EXISTS visiteurMusee;
DROP TABLE IF EXISTS groupe;
DROP TABLE IF EXISTS guide;
DROP TABLE IF EXISTS habitation;

CREATE TABLE habitation
(
    idHabitation    INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    departement     VARCHAR(100)       NULL,
    pays            VARCHAR(100)       NULL,
    nombre          INT                NOT NULL
);

CREATE TABLE guide
(
    idGuide    INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    prenom     VARCHAR(100)       NOT NULL,
    nom        VARCHAR(100)       NOT NULL,
    guideForet BOOL               NOT NULL,
    Adresse    VARCHAR(255)       NOT NULL
);

CREATE TABLE visiteurMusee(
    idVisiteurMusee  INT AUTO_INCREMENT  NOT NULL PRIMARY KEY,
    prixPleinTarif   DECIMAL (4,2)       NOT NULL ,
    nombrePleinTarif INT                 NOT NULL ,
    nombreDemiTarif  INT                 NOT NULL ,
    dateMusee        DATE                NOT NULL ,
    idHabitation         INT                 NOT NULL ,
    idGuide          INT                 NOT NULL ,
    FOREIGN KEY (idHabitation) REFERENCES habitation(idHabitation),
    FOREIGN KEY (idGuide) REFERENCES guide(idGuide)
);

CREATE TABLE groupe(
    idGroupe        INT AUTO_INCREMENT   NOT NULL PRIMARY KEY,
    NombrePersonnes INT                  NOT NULL,
    nomDuGroupe     VARCHAR(100)         NOT NULL,
    idGuide         INT                  NOT NULL,
    FOREIGN KEY (idGuide) REFERENCES guide(idGuide)
    );

CREATE TABLE visiteurForet(
    idVisiteurForet  INT AUTO_INCREMENT  NOT NULL PRIMARY KEY,
    prixPleinTarif   DECIMAL(4,2)        NOT NULL,
    nombreDemiTarif  INT                 NOT NULL,
    nombrePleinTarif INT                 NOT NULL,
    dateForet        DATE                NOT NULL,
    idGroupe         INT                 NOT NULL,
    FOREIGN KEY (idGroupe) REFERENCES groupe(idGroupe)
);

-- Insertion des données dans la table guide
INSERT INTO guide (prenom, nom, guideForet, adresse) VALUES
    ('Jean', 'Dupont', TRUE, '10 Rue des Forges, 35380 Paimpont'),
    ('Marc', 'Durand', FALSE, '8 Rue des Chênes, 35380 Plélan-le-Grand'),
    ('Marie', 'Lefevre', TRUE, '5 Rue de la Forêt, 35380 Paimpont'),
    ('Sophie', 'Dubois', FALSE, '6 Rue des Sources, 35380 Paimpont'),
    ('Claire', 'Moreau', TRUE, '16 Rue de la Mairie, 35380 Beignon');

-- Insertion des données dans la table habitation
INSERT INTO habitation (departement, pays, nombre) VALUES
   ('Ille-et-Vilaine', 'France', 2),
   ('Côtes-d\'Armor', 'France', 3),
   ('Morbihan', 'France', 1),
   ('Finistère', 'France', 5),
   ('Loire-Atlantique', 'France', 4),
   (NULL, 'Allemagne', 2),
   (NULL, 'Espagne', 3),
   (NULL, 'Italie', 1),
   (NULL, 'Royaume-Uni', 5);

-- Insertion des données dans la table visiteurMusee
INSERT INTO visiteurMusee (prixPleinTarif, nombrePleinTarif, nombreDemiTarif, dateMusee, idHabitation, idGuide) VALUES
   (8.00, 12, 3, '2024-07-02', 1, 1),
   (8.00, 15, 4, '2024-07-03', 2, 2),
   (8.00, 14, 5, '2024-07-04', 3, 3),
   (8.00, 13, 3, '2024-07-05', 4, 4),
   (8.00, 11, 5, '2024-07-06', 5, 5);

-- Insertion des données dans la table groupe
INSERT INTO groupe (nombrePersonnes, nomDuGroupe, idGuide) VALUES
   (9, 'Lancelot', 1),
   (11, 'Morgane', 1),
   (10, 'Merlin', 1),
   (10, 'Viviane', 2),
   (8, 'Arthur', 2),
   (12, 'Galahad', 2),
   (9, 'Guenievre', 3),
   (11, 'Perceval', 3),
   (10, 'Gauvain', 3);

-- Jour 1: Total 210

INSERT INTO visiteurForet (prixPleinTarif, nombreDemiTarif, nombrePleinTarif, dateForet, idGroupe) VALUES
-- Jour 2: Total 265
    (10.00, 1, 6, '2024-07-02', 1),  -- 10.00 * 6 + 10.00 / 2 * 1 = 60 + 5 = 65
    (10.00, 2, 5, '2024-07-02', 2),  -- 10.00 * 5 + 10.00 / 2 * 2 = 50 + 10 = 60
    (10.00, 1, 8, '2024-07-02', 3),  -- 10.00 * 8 + 10.00 / 2 * 1 = 80 + 5 = 85

-- Jour 2: Total 265
    (10.00, 4, 7, '2024-07-03', 4),  -- 10.00 * 7 + 10.00 / 2 * 4 = 70 + 20 = 90
    (10.00, 5, 8, '2024-07-03', 5),  -- 10.00 * 8 + 10.00 / 2 * 5 = 80 + 25 = 105
    (10.00, 3, 8, '2024-07-03', 6),  -- 10.00 * 8 + 10.00 / 2 * 3 = 80 + 15 = 95

-- Jour 3: Total 230
    (10.00, 3, 5, '2024-07-04', 7),  -- 10.00 * 5 + 10.00 / 2 * 3 = 50 + 15 = 65
    (10.00, 4, 6, '2024-07-04', 8),  -- 10.00 * 6 + 10.00 / 2 * 4 = 60 + 20 = 80
    (10.00, 3, 7, '2024-07-04', 9);  -- 10.00 * 7 + 10.00 / 2 * 3 = 70 + 15 = 85
