-- liste des recettes journalières des visites des musée

-- Création de la vue pour les recettes de la forêt
CREATE OR REPLACE VIEW VueForet AS
SELECT 'Forêt' AS Type,
       f.dateForet AS Date,
       SUM(f.prixPleinTarif * f.nombrePleinTarif + (f.prixPleinTarif / 2) * f.nombreDemiTarif) AS Somme
FROM visiteurForet f
GROUP BY f.dateForet;

-- Création de la vue pour les recettes du musée
CREATE OR REPLACE VIEW VueMusee AS
SELECT 'Musée' AS Type,
       m.dateMusee AS Date,
       SUM(m.prixPleinTarif * m.nombrePleinTarif + (m.prixPleinTarif / 2) * m.nombreDemiTarif) AS Somme
FROM visiteurMusee m
GROUP BY m.dateMusee;

-- Utilisation des vues pour obtenir le résultat final
SELECT * FROM VueForet
UNION ALL
SELECT * FROM VueMusee;